//===============
//=============== apply grey scale
//===============

function processingGreyscale(){
	//get your image data.
	var MyImageData;
	try {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width,canvas.height);
		} catch (e) {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		}
		console.log(myImageData);
		
		//loop over each pixel and invert the colours.
		var pixelComponents = myImageData.data;
		var n = pixelComponents.length;
		for (var i = 0; i < n; i += 4) {
			//One pixel:
			var average = (pixelComponents[i ] + pixelComponents[i+1] + pixelComponents[i+2]) /3;
			
			pixelComponents[i ] = pixelComponents[i ] = average; //red
			pixelComponents[i+1] = pixelComponents[i+1] = average; //green
			pixelComponents[i+2] = pixelComponents[i+2] = average; //blue
			// i+3 is alpha (the fourth element).
		}
		
		// Draw the ImageData object at the given (x,y) coordinates. 
		canvas.ctx.putImageData(myImageData, 0,0);
}

//===============
//=============== option grey scale
//===============

//this function checks the strength which has to be applied
function strengthGreyscale(){
	strength = document.getElementById('selectGreyscale').value;
	console.log(strength);
	optionGreyscale(strength);
}

function optionGreyscale(strength){
	//get your image data.
	var MyImageData;
	try {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width,canvas.height);
		} catch (e) {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		}
		console.log(myImageData);
		
		//loop over each pixel and invert the colours.
		var pixelComponents = myImageData.data;
		var n = pixelComponents.length;
		for (var i = 0; i < n; i += 4) {
			//One pixel:
			var average = (pixelComponents[i ] + pixelComponents[i+1] + pixelComponents[i+2]) /strength;
			
			pixelComponents[i ] = pixelComponents[i ] = average; //red
			pixelComponents[i+1] = pixelComponents[i+1] = average; //green
			pixelComponents[i+2] = pixelComponents[i+2] = average; //blue
			// i+3 is alpha (the fourth element).
		}
		
		// Draw the ImageData object at the given (x,y) coordinates. 
		canvas.ctx.putImageData(myImageData, 0,0);
}