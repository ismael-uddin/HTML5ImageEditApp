function processingBrightness(){
	//get your image data.
	var MyImageData;
	try {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width,canvas.height);
		} catch (e) {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		}
		console.log(myImageData);
		
		//loop over each pixel and invert the colours.
		var pixelComponents = myImageData.data;
		var n = pixelComponents.length;
		for (var i = 0; i < n; i += 4) {
			//One pixel:
			pixelComponents[i ] = pixelComponents[i ] +10; //red
			pixelComponents[i+1] = pixelComponents[i+1] +10; //green
			pixelComponents[i+2] = pixelComponents[i+2] +10; //blue
			// i+3 is alpha (the fourth element).
		}
		
		// Draw the ImageData object at the given (x,y) coordinates. 
		canvas.ctx.putImageData(myImageData, 0,0);
}

//=======================================================================
//========================processing Brightness slider===================
//=======================================================================	
//grabs the strength of the slider
function Brightness(){
	var x = document.getElementById("sliderBrightness").value;
    document.getElementById("displayBrightness").innerHTML = x;
		SBrightness(x);
}
		
function SBrightness(x){
		//get your image data.
	var MyImageData;
	try {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width,canvas.height);
		} catch (e) {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		}
		console.log(myImageData);
		
		//loop over each pixel and invert the colours.
		var pixelComponents = myImageData.data;
		var n = pixelComponents.length;
		for (var i = 0; i < n; i += 4) {
			//One pixel:
			pixelComponents[i ] = pixelComponents[i ] + x; //red
			pixelComponents[i+1] = pixelComponents[i+1] + x; //green
			pixelComponents[i+2] = pixelComponents[i+2] + x; //blue
			// i+3 is alpha (the fourth element).
		}
		
		// Draw the ImageData object at the given (x,y) coordinates. 
		canvas.ctx.putImageData(myImageData, 0,0);
}

//=======================================================================
//========================processing Brightness option===================
//=======================================================================	

function strengthBrightness(){
	strength = document.getElementById('selectBrightness').value;
	console.log(strength);
	optionBrightness(strength);
}

function optionBrightness(strength){
	//get your image data.
	var MyImageData;
	try {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		} catch (e) {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		}
		console.log(myImageData);
		console.log(strength);
			//loop over each pixel and invert the colours.
			var pixelComponents = myImageData.data;
			var n = pixelComponents.length;
				for (var i = 0; i < n; i += 4) {
						//One pixel:
						pixelComponents[i ] = pixelComponents[i ] + strength; //red
						pixelComponents[i+1] = pixelComponents[i+1] +strength; //green
						pixelComponents[i+2] = pixelComponents[i+2] +strength; //blue
						pixelComponents[i+2] = pixelComponents[i+2] +strength; //blue						
						// i+3 is alpha (the fourth element).
				}
				// Draw the ImageData object at the given (x,y) coordinates. 
				canvas.ctx.putImageData(myImageData, 0,0);
}