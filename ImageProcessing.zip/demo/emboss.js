function Emboss(){
var convolutionWidth = 3;
var convolutionHeight = 3;
var factor = 1.0; 
var bias = 128;

// The Convolution mask - 1 (x).
var convolutionMask1 = new Array(convolutionHeight);
for (i=0; i < convolutionHeight; i++){
	convolutionMask1[i]=new Array(convolutionWidth);
}
convolutionMask1[0][0] = -1.0;	convolutionMask1[1][0] = 0.0; 	convolutionMask1[2][0] = 1.0;
convolutionMask1[0][1] = -1.0; 	convolutionMask1[1][1] = 0.0; 	convolutionMask1[2][1] = 1.0;
convolutionMask1[0][2] = -1.0; 	convolutionMask1[1][2] = 0.0; 	convolutionMask1[2][2] = 1.0;
// END:- The Convolution mask.

var convolutionKernel_OutputArraySize = ((convolutionWidth * convolutionHeight) * 4);	
var convolutionKernel_Output = new Array(convolutionKernel_OutputArraySize);
// END:- Convolution kernel - output.

//calls processingEmboss which applys filter
processingEmboss();

function processingEmboss(){
var myImageData;
	var newImageData;
	try {
      	myImageData = canvas.ctx.getImageData(0, 0, canvas.width, canvas.height);
		newImageData = canvas.ctx.createImageData(canvas.width, canvas.height);
    } catch (e) {
      	myImageData = canvas.ctx.getImageData(0, 0, canvas.width, canvas.height);
		newImageData = canvas.ctx.createImageData(canvas.width, canvas.height);
    }

	var processX = true;
	var processY = true;
	var threshold = 100;

	// Pixel Group Processing x..
	// -----------------------
		var convolutionMask = convolutionMask1;
		alert("Starting group pixel processing");

		// Loop over each pixel on the canvas.
		for (var x = 0; x < canvas.width; x++) {
			for (var y = 0; y < canvas.height; y++) {
	            // Index of the pixel in the array
	            var idx = (x + y * canvas.width) * 4;

				// Indexes for the convolution kernel (in screen coordinates).	
				for (var filterx = 0; filterx < convolutionWidth; filterx++) {
					for (var filtery = 0; filtery < convolutionHeight; filtery++) {
						var tmpX = ((x - Math.floor(convolutionWidth / 2))  + filterx + canvas.width)  % canvas.width;
						var tmpy = ((y - Math.floor(convolutionHeight / 2)) + filtery + canvas.height) % canvas.height;
						var convolutionKernel_Index = (tmpX + tmpy * canvas.width) * 4; 

						var outputIndex = (filterx + filtery * convolutionWidth) * 4;
						convolutionKernel_Output[outputIndex  ] = convolutionMask[filterx][filtery] * myImageData.data[convolutionKernel_Index  ];
						convolutionKernel_Output[outputIndex+1] = convolutionMask[filterx][filtery] * myImageData.data[convolutionKernel_Index+1];
						convolutionKernel_Output[outputIndex+2] = convolutionMask[filterx][filtery] * myImageData.data[convolutionKernel_Index+2];
						convolutionKernel_Output[outputIndex+3] = 255;						
					}
				}		

				// Loop through the output values. Add together and divide by the size of the kernel.
				var newPixel = new Array(4);
				for (i=0; i < 4; i++){
					newPixel[i] = 0;				
				}
				for (i=0; i < convolutionKernel_OutputArraySize; i+=4){
					newPixel[0] = newPixel[0] + convolutionKernel_Output[i  ];
					newPixel[1] = newPixel[1] + convolutionKernel_Output[i+1];
					newPixel[2] = newPixel[2] + convolutionKernel_Output[i+2];
					newPixel[3] = newPixel[3] + convolutionKernel_Output[i+3];				
				}
				
				var avg = newPixel[1] + newPixel[2] / 3;
				newPixel[0] = avg;
				newPixel[1] = avg;
				newPixel[2] = avg;
				
				// Set the new pixel colour.
				newImageData.data[idx  ] = Math.min( Math.max( (newPixel[0] * factor + bias), 0), 255); // red
	  			newImageData.data[idx+1] = Math.min( Math.max( (newPixel[1] * factor + bias), 0), 255); // green
	  			newImageData.data[idx+2] = Math.min( Math.max( (newPixel[2] * factor + bias), 0), 255); // blue
				newImageData.data[idx+3] = Math.min( Math.max( newPixel[3], 0), 255); // Alpha.
					
			}
		}

		// Draw the ImageData object at the given (x,y) coordinates.
		canvas.ctx.putImageData(newImageData, 0,0);

		alert("Finished group pixel processing x.");
}
}