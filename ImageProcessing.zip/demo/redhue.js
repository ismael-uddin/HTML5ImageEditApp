//=======================================================================
//=======================processing red hue selection====================
//=======================================================================	
//variable used to hold the pixel data which is send for selective 
var selectedpixels;

//function checks if checkbox is ticked
function RedHueCheck(checkbox) {
	console.log('RedHueCheck: ' + checkbox.checked);
	if (checkbox.checked) {
		init();
	}
}		
		//function checks when the canvas is clicked down
		function init(a)
		{
		canvas.canvas.addEventListener("mousedown", getPosition, false);
		}
		
		//records x and y position of mouse on canvas
		function getPosition(event)
		{
			var x = new Number();
			var y = new Number();

			if (event.x != undefined && event.y != undefined)
			{
			  x = event.x;
			  y = event.y;
			  
			} 
			
			x -= canvas.canvas.offsetLeft;
			y -= canvas.canvas.offsetTop;

			console.log("x: " + x + "  y: " + y );
			xy(x,y);
		}
		//used x and y to calculate pixel data and then uses it to loop over.
		function xy(x,y){		
			var x = x;
			var y = y;
			selectedpixels = canvas.ctx.getImageData(x,y,1,1).data;
			//console.log(selectedpixels);
			selectRedHue(selectedpixels);
				
				function selectRedHue(arg1){
					//get your image data.
					var MyImageData;
					try {
						myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
						} catch (e) {
						myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
						}
						console.log(myImageData);
						console.log(selectedpixels);
						
							//loop over each pixel
							var pixelComponents = myImageData.data;
							var n = pixelComponents.length;
								for (var i = 0; i < n; i += 4) {
									if((selectedpixels[0]) == pixelComponents[i]
									|| selectedpixels[1] == pixelComponents[i+1] 
									|| selectedpixels[2] == pixelComponents[i+2]
									&& selectedpixels[3] == pixelComponents[i+3]){									
										//One pixel:
										pixelComponents[i ] = pixelComponents[i ] +100; //red
										pixelComponents[i+1] = pixelComponents[i+1] +0; //green
										pixelComponents[i+2] = pixelComponents[i+2] +0; //blue					
										// i+3 is alpha (the fourth element).
									}else{
										pixelComponents[i ] = pixelComponents[i ] + 0; //red
										pixelComponents[i+1] = pixelComponents[i+1] +0; //green
										pixelComponents[i+2] = pixelComponents[i+2] +0; //blue
									}
								}
								// Draw the ImageData object at the given (x,y) coordinates. 
								canvas.ctx.putImageData(myImageData, 0,0);		
				}
		}		

//=======================================================================
//===========================processing red hue =========================
//=======================================================================			


function applyRedHue(){
			//get your image data.
					var MyImageData;
					try {
						myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
						} catch (e) {
						myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
						}
						console.log(myImageData);
						
							//loop over each pixel
							var pixelComponents = myImageData.data;
							var n = pixelComponents.length;
								for (var i = 0; i < n; i += 4) {								
									//One pixel:
									pixelComponents[i ] = pixelComponents[i ] + 10; //red
									pixelComponents[i+1] = pixelComponents[i+1] +0; //green
									pixelComponents[i+2] = pixelComponents[i+2] +0; //blue					
									// i+3 is alpha (the fourth element).
								}
								// Draw the ImageData object at the given (x,y) coordinates. 
								canvas.ctx.putImageData(myImageData, 0,0);		
}

		
//=======================================================================
//========================processing red hue slider======================
//=======================================================================	
//function checks when slider is moved and uses the value to apply filter
function processingRedHue(){
	var x = document.getElementById("sliderRedHue").value;
    document.getElementById("displayredhue").innerHTML = x;
		RedHue(x);
}
		
function RedHue(x){
			//get your image data.
					var MyImageData;
					try {
						myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
						} catch (e) {
						myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
						}
						console.log(myImageData);
						
							//loop over each pixel
							var pixelComponents = myImageData.data;
							var n = pixelComponents.length;
								for (var i = 0; i < n; i += 4) {								
									//One pixel:
									pixelComponents[i ] = pixelComponents[i ] + x; //red
									pixelComponents[i+1] = pixelComponents[i+1] +0; //green
									pixelComponents[i+2] = pixelComponents[i+2] +0; //blue					
									// i+3 is alpha (the fourth element).
								}
								// Draw the ImageData object at the given (x,y) coordinates. 
								canvas.ctx.putImageData(myImageData, 0,0);		
}

//=======================================================================
//========================processing red hue option======================
//=======================================================================	
//function checks when an option is selected
function strengthredhue(){
	strength = document.getElementById('selectRedHue').value;
	console.log(strength);
	optionRedHue(strength);
}

function optionRedHue(strength){
	//get your image data.
	var MyImageData;
	try {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		} catch (e) {
		myImageData = canvas.ctx.getImageData(0,0, canvas.width, canvas.height);
		}
		console.log(myImageData);
		console.log(strength);
			//loop over each pixel and invert the colours.
			var pixelComponents = myImageData.data;
			var n = pixelComponents.length;
				for (var i = 0; i < n; i += 4) {
						//One pixel:
						pixelComponents[i ] = pixelComponents[i ] + strength; //red
						pixelComponents[i+1] = pixelComponents[i+1] +0; //green
						pixelComponents[i+2] = pixelComponents[i+2] +0; //blue
						pixelComponents[i+2] = pixelComponents[i+2] +0; //blue						
						// i+3 is alpha (the fourth element).
				}
				// Draw the ImageData object at the given (x,y) coordinates. 
				canvas.ctx.putImageData(myImageData, 0,0);
}