//=======================================================================
//===============================create canvas===========================
//=======================================================================
var newCanvas = function(width,height){
	this.canvas = document.createElement("canvas");
	this.width = width;
	this.height = height;
	this.ctx = this.canvas.getContext("2d");
}

//=======================================================================
//=========================draw image from path==========================
//=======================================================================
//read file when its uploaded

function readFile() 
{ 
	var fullPath = document.getElementById('bimage').value;
	console.log(fullPath);
	if (!fullPath.length) 
	{
		 alert('Please select a file!');
	}else if (fullPath) {
		var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
		var filename = fullPath.substring(startIndex);
		if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
			filename = filename.substring(1);
			alert(filename + " has been loaded");
			drawImageFromPath(filename);
			return filename;
		}
	}
}

//=======================================================================
//======================draw uploaded image on canvas====================
//=======================================================================

function drawImageFromPath(filename){
	console.log(filename);
	
	var img56 = document.createElement("img");
	img56.src = filename;
	img56.onload = function(){
	canvas1.loadImage(this);
	canvas.loadImage(this);
	console.log(this);
	}
}


//=======================================================================
//====================draws image on canvas from grid====================
//=======================================================================			
newCanvas.prototype.loadImage = function(img){
	this.ctx.drawImage(img,0,0,this.canvas.width,this.canvas.height);
}

//get pixel data
newCanvas.prototype.getPixelData = function(){
	return this.ctx.getImageData(0,0,this.canvas.width,this.canvas.height);
}